if not ZygorGuidesViewer then return end
ZygorGuidesViewer.DisplayModelsExtra={
[02592]={cy=-0.20,cz=1.60,camscale=1.70},
[11091]={cy=-0.20,cz=1.60,camscale=1.70},
[11095]={cy=-0.20,cz=1.60,camscale=1.70},
[24045]={camscale=2.00},
[30904]={cy=-0.20,cz=1.60,camscale=1.70},
[44984]={cy=0.20,cz=1.00,camscale=2.10},
}

