local ZGV = ZygorGuidesViewer
if not ZGV then return end

local FONT=ZGV.Font
local FONTBOLD=ZGV.FontBold
local FONTSTATUS="Fonts\\ARIALN.TTF"
local L = ZGV.L
local CHAIN = ZGV.ChainCall

local ZGVG=ZGV.Gold
local TRENDS_OLD = 24 * 4 --h

local Appraiser

if not ZGV.Gold.Appraiser then
	Appraiser = {}
	ZGV.Gold.Appraiser = Appraiser
else
	Appraiser = ZGV.Gold.Appraiser 
end

local ui = ZGV.UI
local SkinData = ui.SkinData

local HEADER_HEIGHT = 30		-- exported to GoldHelp.lua
local FOOTER_HEIGHT = 25
local SCROLL_WIDTH=15		-- read only

local TAB_NAVIGATION_INVENTORY = {"stacksize", "stackcount", "bidgold", "bidsilver", "bidcopper", "buyoutgold", "buyoutsilver", "buyoutcopper"}
local TAB_NAVIGATION_SEARCH = {"searchname", "pricegold", "pricesilver", "pricecopper", "maxcount"}

local SELL_INVENTORY_COLUMS = {
	{ title="", width=15, headerwidth=15, titlej="LEFT", textj="LEFT", name="icon", type="icon", onentertooltip=function(row) if row.item.bag then GameTooltip:SetBagItem(row.item.bag,row.item.slot) else GameTooltip:SetItemByID(row.item.itemid) end end},
	{ title="ITEM", width=190, titlej="LEFT", textj="LEFT", name="name" },
	{ title="PRICE", width=100, titlej="RIGHT", textj="RIGHT", name="price" },
	{ title="", width=15, titlej="CENTER", textj="CENTER", name="status", type="icon", onentertooltip=function(row) GameTooltip:AddLine( row.item.statusText ) end },
}

local SELL_INVENTORY_DATA = {
	ROW_COUNT = 14,
	LIST_WIDTH = 360,
	LIST_HEIGHT = 340,
	POSX = 8,
	POSY = -8,
	STRATA = "HIGH",
}

local SELL_AUCTIONS_COLUMNS = {
	{ title="", width=15, headerwidth=15, titlej="LEFT", textj="LEFT", name="icon", type="icon", 
		onentertooltip=function(row) if row.item.BattlePetName then GameTooltip:AddLine(row.item.BattlePetName) return end GameTooltip:SetHyperlink(row.item.itemlink) end},
	{ title="STACK", width=180, titlej="LEFT", textj="LEFT", name="name" },
	{ title="UNIT", width=100, titlej="RIGHT", textj="RIGHT", name="uprice" },
	{ title="STACK", width=100, titlej="RIGHT", textj="RIGHT", name="sprice" },
}

local SELL_AUCTIONS_DATA = {
	ROW_COUNT = 6,
	LIST_WIDTH = 435,
	LIST_HEIGHT = 150,
	POSX = 385,
	POSY = -198,
	STRATA = "HIGH",
}

local BUY_INVENTORY_COLUMS = {
	{ title="", width=15, headerwidth=15, titlej="LEFT", textj="LEFT", name="icon", type="icon", onentertooltip=function(row) if not row.item then return end if row.item.bag then GameTooltip:SetBagItem(row.item.bag,row.item.slot) else GameTooltip:SetItemByID(row.item.itemid) end end},
	{ title="ITEM", width=170, titlej="LEFT", textj="LEFT", name="name" },
	{ title="PRICE", width=120, titlej="RIGHT", textj="RIGHT", name="price" },
	{ title="", width=15, titlej="CENTER", textj="CENTER", name="status", type="icon", onentertooltip=function(row) if not row.item then return end GameTooltip:AddLine( row.item.statusText ) end },
}

local BUY_INVENTORY_DATA = {
	ROW_COUNT = 14,
	LIST_WIDTH = 360,
	LIST_HEIGHT = 340,
	POSX = 8,
	POSY = -8,
	STRATA = "HIGH",
}

local BUY_AUCTIONS_COLUMNS = {
	{ title="", width=15, headerwidth=15, titlej="LEFT", textj="LEFT", name="icon", type="icon", 
		onentertooltip=function(row) if row.item.BattlePetName then GameTooltip:AddLine(row.item.BattlePetName) return end GameTooltip:SetHyperlink(row.item.itemlink) end},
	{ title="SIZE", width=180, titlej="LEFT", textj="LEFT", name="name" },
	{ title="UNIT", width=100, titlej="RIGHT", textj="RIGHT", name="uprice" },
	{ title="STACK", width=100, titlej="RIGHT", textj="RIGHT", name="sprice" },
}

local BUY_AUCTIONS_DATA = {
	ROW_COUNT = 8,
	LIST_WIDTH = 435,
	LIST_HEIGHT = 192,
	POSX = 385,
	POSY = -156,
	STRATA = "HIGH",
}

local BUY_SEARCH_COLUMNS = {
	{ title="", width=15, headerwidth=15, titlej="LEFT", textj="LEFT", name="icon", type="icon", 
		onentertooltip=function(row) GameTooltip:SetHyperlink(row.item.itemlink) end},
	{ title="ITEM NAME", width=375, titlej="LEFT", textj="LEFT", name="name" },
	{ title="", width=12, titlej="RIGHT", textj="RIGHT", name="action", type="button", 
		texture=ZGV.DIR.."\\Skins\\goldpricestatusicons", 
		textureoffset={11/16,12/16,0,1},
		texturecolor=SkinData("ButtonColor2"),
	},
}

local BUY_SEARCH_DATA = {
	ROW_COUNT = 8,
	LIST_WIDTH = 435,
	LIST_HEIGHT = 192,
	POSX = 0,
	POSY = -146,
	STRATA = "HIGH",
}

local DROPDOWN_STYLE=2

function Appraiser:CreateMainFrame()
	self.MainFrame = CHAIN(ui:Create("Frame",UIParent,"ZygorAppraiser"))
		:SetFrameStrata("HIGH")
		:SetFrameLevel(AuctionFrame:GetFrameLevel()+1)
		:SetToplevel(enable)
		:SetBackdropColor(ZGV.HTMLColor("#222222ff"))
		.__END


	local MF = self.MainFrame 
	MF:ClearAllPoints()
	MF:SetPoint("TOPLEFT",AuctionFrame,"TOPLEFT",1,1)
	MF:SetPoint("BOTTOMRIGHT",AuctionFrame,"BOTTOMRIGHT",1,11)

	-- Header
	MF.HeaderFrame = CHAIN(ui:Create("Frame",MF,"ZygorAppraiserHeader"))
		:SetPoint("TOPLEFT",1,-1)
		:SetPoint("TOPRIGHT",-1,-1)
		:SetHeight(HEADER_HEIGHT)
		:SetFrameStrata("HIGH")
		:SetFrameLevel(MF:GetFrameLevel()+2)
		:SetBackdropColor(0,0,0,1)
		:SetBackdropBorderColor(0,0,0,0)
		:SetToplevel(enable)
		.__END

		MF.HeaderFrame.Logo = CHAIN(MF.HeaderFrame:CreateTexture())
			:SetPoint("TOP",MF.HeaderFrame,"TOP",0,-3) 
			:SetSize(100,25)
			:SetTexture(SkinData("TitleLogo"))
		.__END

		MF.HeaderFrame.Title = CHAIN(MF.HeaderFrame:CreateFontString())
			:SetPoint("TOPLEFT",8,-8)
			:SetFont(FONT,14) 
			:SetTextColor(unpack(SkinData("TabSelectedColor")))
			:SetText("Zygor Inventory")
		 .__END

		MF.HeaderFrame.close = CHAIN(CreateFrame("Button",nil,MF.HeaderFrame))
			:SetPoint("TOPRIGHT",-5,-5)
			:SetSize(17,17)
			:SetScript("OnClick", function() CloseAuctionHouse() end)
			.__END
		ZGV.AssignButtonTexture(MF.HeaderFrame.close,(SkinData("TitleButtons")),6,32)

		--[[
		MF.HeaderFrame.info = CHAIN(CreateFrame("Button",nil,MF.HeaderFrame))
			:SetPoint("TOPRIGHT",MF.HeaderFrame.close,"TOPLEFT",-5,0)
			:SetSize(17,17)
			:SetScript("OnClick", function() Appraiser:ToggleHelpPage() end)
			.__END
		ZGV.AssignButtonTexture(MF.HeaderFrame.info,(SkinData("TitleButtons")),18,32)
		--]]

		MF.HeaderFrame.goldguide = CHAIN(CreateFrame("Button", "ZA_Menu_GoldGuide" , MF.HeaderFrame))
			:SetSize(17,17)
			--:SetPoint("TOPRIGHT",MF.HeaderFrame.info,"TOPLEFT",-5,0)
			:SetPoint("TOPRIGHT",MF.HeaderFrame.close,"TOPLEFT",-5,0)
			:SetScript("OnClick", function() ZGV.Goldguide:Initialise() end)
			:SetScript("OnEnter",function()
				GameTooltip:SetOwner(MF.HeaderFrame.goldguide, "ANCHOR_CURSOR")
				GameTooltip:AddLine("Open Gold Guide")
				GameTooltip:Show()
			end)
			:SetScript("OnLeave",function()
				GameTooltip:FadeOut()
			end)
			:Show()
		.__END
		ZGV.AssignButtonTexture(MF.HeaderFrame.goldguide,(SkinData("TitleButtons")),22,32)


	MF.ContentFrame = CHAIN(CreateFrame("Frame", "ZygorAppraiserContent", MF))
		:SetPoint("TOPLEFT",MF.HeaderFrame,"BOTTOMLEFT")
		:SetPoint("TOPRIGHT",MF.HeaderFrame,"BOTTOMRIGHT")
		:SetHeight(380)
		:Show()
	.__END

	-- Footer
	MF.FooterFrame = CHAIN(ui:Create("Frame",MF,"ZygorAppraiserFooter"))
		:SetPoint("TOPLEFT",MF.ContentFrame,"BOTTOMLEFT")
		:SetPoint("TOPRIGHT",MF.ContentFrame,"BOTTOMRIGHT")
		:SetHeight(FOOTER_HEIGHT)
		:SetFrameStrata("HIGH")
		:SetFrameLevel(MF:GetFrameLevel()+1)
		:SetBackdropColor(0,0,0,1)
		:SetBackdropBorderColor(0,0,0,0)
		:SetToplevel(enable)
		.__END
		MF.FooterUpdated = CHAIN(MF.FooterFrame:CreateFontString())
			:SetPoint("BOTTOMLEFT",5,5)
			:SetFont(FONTBOLD,12)
			:SetText("LAST UPDATED:")
		.__END

		MF.FooterUpdatedTime = CHAIN(MF.FooterFrame:CreateFontString())
			:SetPoint("LEFT",MF.FooterUpdated ,"RIGHT",5,0)
			:SetFont(FONT,12)
			:SetText("no time")
		.__END

		MF.FooterSettingsButton = CHAIN(CreateFrame("Button",nil,MF.FooterFrame))
			:SetPoint("BOTTOMRIGHT",-5,5)
			:SetSize(15,15)
			:SetScript("OnClick",function() ZGV:OpenOptions() end)
		.__END
		ZGV.AssignButtonTexture(MF.FooterSettingsButton,(SkinData("TitleButtons")),5,32)

		MF.progressFrame = CHAIN(CreateFrame("Frame","progressFrame",MF.FooterFrame))
			:SetBackdrop(SkinData("ProgressBarBackdrop"))
			:SetBackdropColor(unpack(SkinData("ProgressBarBackdropColor")))
			:SetBackdropBorderColor(unpack(SkinData("ProgressBarBackdropBorderColor")))
			:SetSize(MF:GetWidth(),7)
			:SetHeight(SkinData("ProgressBarHeight"))
			:SetFrameStrata("HIGH")
			:SetFrameLevel(self.MainFrame:GetFrameLevel()+3)
			:SetPoint("TOP",MF.FooterFrame,"BOTTOM",0,-1)
			:Hide()
		.__END
		
		MF.progressFrame.tex = CHAIN(MF.progressFrame:CreateTexture())
			:SetHeight(SkinData("ProgressBarHeight")-2)
			:SetPoint("TOPLEFT",MF.progressFrame,"TOPLEFT",1,-1)
			:SetColorTexture(unpack(SkinData("ProgressBarTexture")))
			:SetVertexColor(unpack(ZGV.CurrentSkinStyle:SkinData("ProgressBarColor") or {0,1,0,1}))
		.__END 
		
		MF.progressFrame.SetPercent = function(self, percent)
			self.tex:SetWidth((percent / 100)*(self:GetWidth()-2))
		end

	Appraiser.Inventory_Frame = self:MakeInventoryTable()
	Appraiser.Buy_Frame = self:MakeBuyTable()

	Appraiser:CreateSystemTab("Inventory","Sell")
	Appraiser:CreateSystemTab("Buy","Buy")

	MF.HelpPageContainer = CHAIN(CreateFrame("Frame", nil, self.MainFrame.ContentFrame ))
		:SetPoint("TOPLEFT")
		:SetPoint("BOTTOMRIGHT")
		:SetWidth(700)
		:SetHeight(1700)
	.__END
		
	MF.HelpPageContent = CHAIN(CreateFrame("SimpleHTML", "ZA_Help_Frame", MF.HelpPageContainer ))
		:SetBackdrop(SkinData("SecBackdrop"))
		:SetBackdropColor(unpack(SkinData("SecBackdropColor")))
		:SetPoint("TOPLEFT",10,-10)
		:SetPoint("BOTTOMRIGHT",-10,10)
		:SetWidth(700)
		:SetHeight(1700)
	.__END
	MF.HelpPageContent.p_font = CreateFont("p_font")	MF.HelpPageContent.p_font:SetFont(ZGV.Font,10)
	MF.HelpPageContent.h1_font = CreateFont("h1_font")	MF.HelpPageContent.h1_font:SetFont(ZGV.Font,12)
	MF.HelpPageContent.h2_font = CreateFont("h2_font")	MF.HelpPageContent.h2_font:SetFont(ZGV.Font,12)
	MF.HelpPageContent.h3_font = CreateFont("h3_font")	MF.HelpPageContent.h3_font:SetFont(ZGV.Font,12)

	MF.HelpPageContent:SetFontObject("p",MF.HelpPageContent.p_font)
	MF.HelpPageContent:SetFontObject("h1",MF.HelpPageContent.h1_font)
	MF.HelpPageContent:SetFontObject("h2",MF.HelpPageContent.h2_font)
	MF.HelpPageContent:SetFontObject("h3",MF.HelpPageContent.h3_font)

	MF.HelpPageContent:SetTextColor(1, 1, 1, 1)
	MF.HelpPageContent:SetTextColor("h1", 1, 0, 1, 1)

	MF.HelpPage = CHAIN(ui:Create("ScrollChild",self.MainFrame.ContentFrame ,"MF_HelpPage",MF.HelpPageContainer))
		:SetBackdrop(SkinData("SecBackdrop"))
		:SetBackdropColor(unpack(SkinData("SecBackdropColor")))
		:SetPoint("TOPLEFT")
		:SetPoint("BOTTOMRIGHT",-15,0)
		:SetFrameStrata("HIGH")
		:SetFrameLevel(self.MainFrame:GetFrameLevel()+1)
		:Hide()
	.__END

	MF.HelpPageContent:SetPoint("TOPLEFT",10,-10)

	MF:Hide()
end
	
function Appraiser:MakeInventoryTable()	
	local container = CHAIN(CreateFrame("Frame", "ZA_Sell_Frame", self.MainFrame.ContentFrame ))
		:SetPoint("TOPLEFT")
		:SetPoint("BOTTOMRIGHT")
		:SetHeight(100)
	.__END

	--------- Inventory list ---------
	container.InventoryList = ui:Create("ScrollTable",container,"ZA_Sell_Inventory",SELL_INVENTORY_COLUMS,SELL_INVENTORY_DATA)

	container.InventoryList:SetScript("OnMouseWheel", function(self,delta)
		Appraiser.InventoryOffset=Appraiser.InventoryOffset-delta
		Appraiser.needToUpdate=true
		Appraiser.MainFrame.hideTooltip=true
	end)
	container.InventoryList.scrollbar:SetScript("OnVerticalScroll",function(me,offset)
		Appraiser.InventoryOffset=math.round(offset)
		Appraiser.needToUpdate=true
	end)

	for n=1,SELL_INVENTORY_DATA.ROW_COUNT do
		container.InventoryList.rows[n].status:SetTexture(ZGV.DIR.."\\Skins\\goldpricestatusicons")
		container.InventoryList.rows[n]:SetScript("OnClick",function(self,button)
			if button == "LeftButton" and container.InventoryList.rows[n].item then
				Appraiser:ActivateSellItem(container.InventoryList.rows[n].item)
			elseif button == "RightButton" then
				Appraiser:InventoryRowMenu(container.InventoryList.rows[n])
			end
		end)
	end

	--------- Auctions list ---------
	container.InventoryAuctionList = ui:Create("ScrollTable",container,"ZA_Sell_Auctions",SELL_AUCTIONS_COLUMNS,SELL_AUCTIONS_DATA)

	container.InventoryAuctionList:SetScript("OnMouseWheel", function(self,delta)
		Appraiser.InventoryAuctionOffset=Appraiser.InventoryAuctionOffset-delta
		Appraiser.needToUpdate=true
		Appraiser.MainFrame.hideTooltip=true
	end)
	container.InventoryAuctionList.scrollbar:SetScript("OnVerticalScroll",function(me,offset)
		Appraiser.InventoryAuctionOffset=math.round(offset)
		Appraiser.needToUpdate=true
	end)
	for n=1,SELL_AUCTIONS_DATA.ROW_COUNT do
		container.InventoryAuctionList.rows[n]:SetScript("OnClick",function()
			Appraiser:SetUndercutToAuction(container.InventoryAuctionList.rows[n])
		end)
	end

	container.auctionslabel = CHAIN(container:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("BOTTOMLEFT",container.InventoryAuctionList,"TOPLEFT",0,0)
		:SetJustifyH("LEFT")
		:SetSize(435,20)
		:SetText("Auctions for: ...")
		.__END
	container.undercutlabel = CHAIN(container:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("BOTTOMLEFT",container.InventoryAuctionList,"TOPLEFT",0,0)
		:SetJustifyH("RIGHT")
		:SetSize(435,20)
		:SetText("Select auction to undercut")
		.__END


	container.InventoryAppraiseButton = CHAIN(ui:Create("Button",container))
		:SetSize(105,20)
		:SetPoint("TOPLEFT",container.InventoryList,"BOTTOMLEFT", 0, -6)
		:SetFont(FONT,12)
		:SetText("Appraise all")
		:SetScript("OnClick", function() if not self.soft_disabled then Appraiser:StartManualScan() end end)
		:SetScript("OnEnter",function(self) 
			CHAIN(GameTooltip):SetOwner(self, "ANCHOR_BOTTOM") 
			:SetText(type(self.tooltip)=="function" and self:tooltip() or tostring(self.tooltip)) 
			:Show() 
			end)
		:SetScript("OnLeave",function(self) GameTooltip:Hide() end)
	.__END
	container.InventoryAppraiseAbortButton = CHAIN(ui:Create("Button",container))
		:SetSize(105,20)
		:SetPoint("TOPLEFT",container.InventoryList,"BOTTOMLEFT", 0, -6)
		:SetFont(FONT,12)
		:SetText("Abort")
		:SetScript("OnClick", function() Appraiser:AbortManualScan() end)
		:Hide()
	.__END


	container.InventoryScanButton = CHAIN(ui:Create("Button",container))
		:SetSize(75,20)
		:SetPoint("TOPRIGHT",container.InventoryList,"BOTTOMRIGHT", 0, -6)
		:SetFont(FONT,12)
		:SetText("Scan")
		:SetScript("OnClick", function() if not self.soft_disabled then Appraiser:Scan() end end)
		:SetScript("OnEnter",function(self) 
			CHAIN(GameTooltip):SetOwner(self, "ANCHOR_BOTTOM") 
			:SetText(type(self.tooltip)=="function" and self:tooltip() or tostring(self.tooltip)) 
			:Show() 
			end)
		:SetScript("OnLeave",function(self) GameTooltip:Hide() end)
	.__END

	container.InventoryScanAbortButton = CHAIN(ui:Create("Button",container))
		:SetSize(75,20)
		:SetPoint("TOPRIGHT",container.InventoryList,"BOTTOMRIGHT", 0, -6)
		:SetFont(FONT,12)
		:SetText("Abort")
		:SetScript("OnClick", function() Appraiser:AbortManualScan() end)
		:Hide()
	.__END


	container.activeIcon = CHAIN(container:CreateTexture())
		:SetPoint("TOPLEFT",container,"TOPLEFT",385,-8)
		:SetSize(20,20)
	.__END
	container.activeIconOverlay = CHAIN(ui:Create("Button",container,"ZA_Details_Frame_Icon"))
		:SetPoint("TOPLEFT",container.activeIcon)
		:SetPoint("BOTTOMRIGHT",container.activeIcon)
		:SetFrameLevel(container:GetFrameLevel()+2)
		:SetBackdropColor(0,0,0,0)
		:SetBackdropBorderColor(0,0,0,0)
		:SetScript("OnEnter",function()
			if Appraiser.ActiveSellingItem then
				GameTooltip:SetOwner(container.activeIconOverlay,"ANCHOR_RIGHT")
				GameTooltip:SetItemByID(Appraiser.ActiveSellingItem.itemid )
				GameTooltip:Show()
			end
		end)
		:SetScript("OnLeave",function()
			GameTooltip:Hide()
		end)
	.__END	
	container.activeName = CHAIN(container:CreateFontString())
		:SetFont(FONT,13)
		:SetPoint("TOPLEFT",container.activeIcon,"TOPRIGHT",8,-2)
		:SetJustifyH("LEFT")
		:SetWidth(220)
		:SetWordWrap(false)
		:SetText("No item selected")
		.__END

	container.activeStatus = CHAIN(container:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("TOPLEFT",container.activeName,"TOPRIGHT",0,-2)
		:SetJustifyH("RIGHT")
		:SetWidth(190)
		:SetWordWrap(false)
		:SetText("No trend data for item.")
		.__END

	container.decor = CHAIN(ui:Create("Frame",container,nil))
		:SetPoint("TOPLEFT",container,"TOPLEFT",385,-30)
		:SetSize(438,1)
		:SetFrameLevel(container:GetFrameLevel()+3)
		:SetBackdropColor(0.3,0.3,0.3,1)
		:SetBackdropBorderColor(0,0,0,0)
	.__END

	container.details = CHAIN(CreateFrame("Frame", "ZA_Details_Frame", container ))
		:SetPoint("TOPLEFT",container,"TOPLEFT",385,-30)
		:SetPoint("BOTTOMRIGHT",container.InventoryAuctionList,"TOPRIGHT",0,-30)
	.__END

	container.stacksizelabel = CHAIN(container.details:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("TOPLEFT",0,-10)
		:SetJustifyH("LEFT")
		:SetWidth(110)
		:SetText("Stack Size")
		.__END
		container.stacksize = CHAIN(ui:Create("EditBox",container.details))
			:SetSize(47,17)
			:SetPoint("LEFT",container.stacksizelabel ,"RIGHT",5,0)
			:SetText("1")
			:SetNumeric(true)
			:SetBackdropColor(0,0,0,1)
			:SetBackdropBorderColor(0.5,0.5,0.5,1)
			:SetTextColor(1,1,1,1)
			:SetScript("OnTabPressed", function() Appraiser:TabKeyNavigation(container,TAB_NAVIGATION_INVENTORY,"stacksize") end)
			:SetScript("OnTextChanged", function(self,user) if not user then return end  ZGV:ScheduleTimer(function() Appraiser:UpdateStackSize() end,0) end)
			:SetScript("OnEditFocusLost", function(self) ZGV:ScheduleTimer(function() Appraiser:UpdateStackSize() end,0) end)
			:SetScript("OnEnter",function(self) if not self:IsEnabled() then Appraiser:ShowDisabledTooltip(self) end end)
			:SetScript("OnLeave",function() GameTooltip:Hide() end)
			.__END
		container.stacksizebutton = CHAIN(ui:Create("Button",container.details))
			:SetSize(62,17)
			:SetPoint("LEFT",container.stacksize ,"RIGHT",8,0)
			:SetFont(FONT,12)
			:SetText("Max")
			:SetScript("OnClick", function() Appraiser:SetMaxStackSize() end)
			.__END

	container.stackcountlabel = CHAIN(container.details:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("TOPLEFT",0,-32)
		:SetJustifyH("LEFT")
		:SetWidth(110)
		:SetText("Stack Count")
		.__END
		container.stackcount = CHAIN(ui:Create("EditBox",container.details))
			:SetSize(47,17)
			:SetPoint("LEFT",container.stackcountlabel ,"RIGHT",5,0)
			:SetText("1")
			:SetNumeric(true)
			:SetBackdropColor(0,0,0,1)
			:SetBackdropBorderColor(0.5,0.5,0.5,1)
			:SetTextColor(1,1,1,1)
			:SetScript("OnTabPressed", function() Appraiser:TabKeyNavigation(container,TAB_NAVIGATION_INVENTORY,"stackcount") end)
			:SetScript("OnTextChanged", function(self,user) if not user then return end  ZGV:ScheduleTimer(function() Appraiser:UpdateStackCount() end,0) end)
			:SetScript("OnEditFocusLost", function(self) ZGV:ScheduleTimer(function() Appraiser:UpdateStackCount() end,0) end)
			:SetScript("OnEnter",function(self) if not self:IsEnabled() then Appraiser:ShowDisabledTooltip(self) end end)
			:SetScript("OnLeave",function() GameTooltip:Hide() end)
			.__END
		container.stackcountbutton = CHAIN(ui:Create("Button",container.details))
			:SetSize(62,17)
			:SetPoint("LEFT",container.stackcount ,"RIGHT",8,0)
			:SetFont(FONT,12)
			:SetText("Max")
			:SetScript("OnClick", function() Appraiser:SetMaxStackCount() end)
			.__END

	container.bidlabel = CHAIN(container.details:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("TOPLEFT",0,-54)
		:SetJustifyH("LEFT")
		:SetWidth(110)
		:SetText("Bid / unit")
		.__END
		container.bidgold = CHAIN(ui:Create("EditBox",container.details))
			:SetSize(47,17)
			:SetPoint("LEFT",container.bidlabel ,"RIGHT",5,0)
			:SetText("0")
			:SetNumeric(true)
			:SetMaxLetters(6)
			:SetBackdropColor(0,0,0,1)
			:SetBackdropBorderColor(0.5,0.5,0.5,1)
			:SetTextColor(1,0.93,0,1)
			:SetScript("OnTabPressed", function() Appraiser:TabKeyNavigation(container,TAB_NAVIGATION_INVENTORY,"bidgold") end)
			:SetScript("OnTextChanged", function(self,user) if not user then return end  Appraiser:SellPriceManual() end)
			.__END
		container.bidsilver = CHAIN(ui:Create("EditBox",container.details))
			:SetSize(20,17)
			:SetPoint("LEFT",container.bidgold ,"RIGHT",12,0)
			:SetText("0")
			:SetNumeric(true)
			:SetMaxLetters(2)
			:SetBackdropColor(0,0,0,1)
			:SetBackdropBorderColor(0.5,0.5,0.5,1)
			:SetTextColor(0.97,0.97,1,1)
			:SetScript("OnTabPressed", function() Appraiser:TabKeyNavigation(container,TAB_NAVIGATION_INVENTORY,"bidsilver") end)
			:SetScript("OnTextChanged", function(self,user) if not user then return end  Appraiser:SellPriceManual() end)
			.__END
		container.bidcopper = CHAIN(ui:Create("EditBox",container.details))
			:SetSize(20,17)
			:SetPoint("LEFT",container.bidsilver ,"RIGHT",12,0)
			:SetText("0")
			:SetNumeric(true)
			:SetMaxLetters(2)
			:SetBackdropColor(0,0,0,1)
			:SetBackdropBorderColor(0.5,0.5,0.5,1)
			:SetTextColor(1,0.66,0.60,1)
			:SetScript("OnTabPressed", function() Appraiser:TabKeyNavigation(container,TAB_NAVIGATION_INVENTORY,"bidcopper") end)
			:SetScript("OnTextChanged", function(self,user) if not user then return end  Appraiser:SellPriceManual() end)
			.__END

	container.buyoutlabel = CHAIN(container.details:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("TOPLEFT",0,-76)
		:SetJustifyH("LEFT")
		:SetWidth(110)
		:SetText("Buyout / unit")
		.__END
		container.buyoutgold = CHAIN(ui:Create("EditBox",container.details))
			:SetSize(47,17)
			:SetPoint("LEFT",container.buyoutlabel ,"RIGHT",5,0)
			:SetText("0")
			:SetNumeric(true)
			:SetMaxLetters(6)
			:SetBackdropColor(0,0,0,1)
			:SetBackdropBorderColor(0.5,0.5,0.5,1)
			:SetTextColor(1,0.93,0,1)
			:SetScript("OnTabPressed", function() Appraiser:TabKeyNavigation(container,TAB_NAVIGATION_INVENTORY,"buyoutgold") end)
			:SetScript("OnTextChanged", function(self,user) if not user then return end  Appraiser:SellPriceManual() end)
			.__END
		container.buyoutsilver = CHAIN(ui:Create("EditBox",container.details))
			:SetSize(20,17)
			:SetPoint("LEFT",container.buyoutgold ,"RIGHT",12,0)
			:SetText("0")
			:SetNumeric(true)
			:SetMaxLetters(2)
			:SetBackdropColor(0,0,0,1)
			:SetBackdropBorderColor(0.5,0.5,0.5,1)
			:SetTextColor(0.97,0.97,1,1)
			:SetScript("OnTabPressed", function() Appraiser:TabKeyNavigation(container,TAB_NAVIGATION_INVENTORY,"buyoutsilver") end)
			:SetScript("OnTextChanged", function(self,user) if not user then return end  Appraiser:SellPriceManual() end)
			.__END
		container.buyoutcopper = CHAIN(ui:Create("EditBox",container.details))
			:SetSize(20,17)
			:SetPoint("LEFT",container.buyoutsilver ,"RIGHT",12,0)
			:SetText("0")
			:SetNumeric(true)
			:SetMaxLetters(2)
			:SetBackdropColor(0,0,0,1)
			:SetBackdropBorderColor(0.5,0.5,0.5,1)
			:SetTextColor(1,0.66,0.60,1)
			:SetScript("OnTabPressed", function() Appraiser:TabKeyNavigation(container,TAB_NAVIGATION_INVENTORY,"buyoutcopper") end)
			:SetScript("OnTextChanged", function(self,user) if not user then return end  Appraiser:SellPriceManual() end)
			.__END

	container.UndercutDropdownLabel = CHAIN(container.details:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("TOPLEFT",0,-98)
		:SetJustifyH("LEFT")
		:SetWidth(110)
		:SetText("Undercut")
		.__END
		container.UndercutDropdown = CHAIN(ui:Create("DropDown",container.details,DROPDOWN_STYLE))
			:SetPoint("BOTTOMLEFT",container.UndercutDropdownLabel,"BOTTOMRIGHT",1,-1)
			:SetSize(120,17)
			:SetText("Undercut")
			:AddTooltip("ANCHOR_TOPLEFT","Select undercutting mode.")
		.__END
		local AH_UNDERCUT_OPTIONS = {
			{L['opt_gold_appraiser_undercut_none'],	0	},
			{L['opt_gold_appraiser_undercut_1p'],	1	},
			{L['opt_gold_appraiser_undercut_2p'],	2	},
			{L['opt_gold_appraiser_undercut_5p'],	5	},
			{L['opt_gold_appraiser_undercut_10p'],	10	},
			{L['opt_gold_appraiser_undercut_20p'],	20	},
			{L['opt_gold_appraiser_undercut_1c'],	10001	},
		}
		for optnum,opt in ipairs(AH_UNDERCUT_OPTIONS) do
			local item = container.UndercutDropdown:AddItem(opt[1],opt[2],function(item)
				ZGV.db.profile.appraiser_undercut = item.userdata.value
				ZGV.Gold.Appraiser:UpdateSellPrice()
				ZGV.Gold.Appraiser.needToUpdate = true
			end)
		end
		container.UndercutDropdown:SetCurrentSelectedByValue(ZGV.db.profile.appraiser_undercut or 0)

	container.durationdropdownlabel = CHAIN(container.details:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("TOPLEFT",0,-120)
		:SetJustifyH("LEFT")
		:SetWidth(110)
		:SetText("Duration")
		.__END
		container.durationdropdown = CHAIN(ui:Create("DropDown",container.details,DROPDOWN_STYLE))
			:SetPoint("BOTTOMLEFT",container.durationdropdownlabel,"BOTTOMRIGHT",1,-1)
			:SetSize(120,17)
			:SetText("Duration")
			:AddTooltip("ANCHOR_TOPLEFT","Select auction duration.")
		.__END
		local AH_DURATION_OPTIONS = {
			{AUCTION_DURATION_ONE,	1	},
			{AUCTION_DURATION_TWO,	2	},
			{AUCTION_DURATION_THREE,3	},
		}
		for optnum,opt in ipairs(AH_DURATION_OPTIONS) do
			local item = container.durationdropdown:AddItem(opt[1],opt[2],function(item)
				ZGV.db.profile.appraiser_duration = item.userdata.value
			end)
		end
		container.durationdropdown:SetCurrentSelectedByValue(ZGV.db.profile.appraiser_duration or 2)


	container.demandlabel = CHAIN(container.details:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("TOPLEFT",250,-10)
		:SetJustifyH("LEFT")
		:SetWidth(80)
		:SetText("Demand:")
		.__END
		container.demand = CHAIN(container.details:CreateFontString())
			:SetFont(FONT,12)
			:SetPoint("LEFT",container.demandlabel ,"RIGHT",5,0)
			:SetJustifyH("RIGHT")
			:SetWidth(100)
			:SetText("n\\a")
			.__END
	container.histhighlabel = CHAIN(container.details:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("TOPLEFT",250,-32)
		:SetJustifyH("LEFT")
		:SetWidth(80)
		:SetText("Hist. High:")
		.__END
		container.histhigh = CHAIN(container.details:CreateFontString())
			:SetFont(FONT,12)
			:SetPoint("LEFT",container.histhighlabel ,"RIGHT",5,0)
			:SetJustifyH("RIGHT")
			:SetWidth(100)
			:SetText("n\\a")
			.__END
	container.histmedlabel = CHAIN(container.details:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("TOPLEFT",250,-54)
		:SetJustifyH("LEFT")
		:SetWidth(80)
		:SetText("Hist. Med:")
		.__END
		container.histmed = CHAIN(container.details:CreateFontString())
			:SetFont(FONT,12)
			:SetPoint("LEFT",container.histmedlabel ,"RIGHT",5,0)
			:SetJustifyH("RIGHT")
			:SetWidth(100)
			:SetText("n\\a")
			.__END
	container.histlowlabel = CHAIN(container.details:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("TOPLEFT",250,-76)
		:SetJustifyH("LEFT")
		:SetWidth(80)
		:SetText("Hist. Low:")
		.__END
		container.histlow = CHAIN(container.details:CreateFontString())
			:SetFont(FONT,12)
			:SetPoint("LEFT",container.histlowlabel ,"RIGHT",5,0)
			:SetJustifyH("RIGHT")
			:SetWidth(100)
			:SetText("n\\a")
			.__END
	container.estvallabel = CHAIN(container.details:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("TOPLEFT",250,-98)
		:SetJustifyH("LEFT")
		:SetWidth(80)
		:SetText("Curr. Price:")
		.__END
		container.estval = CHAIN(container.details:CreateFontString())
			:SetFont(FONT,12)
			:SetPoint("LEFT",container.estvallabel ,"RIGHT",5,0)
			:SetJustifyH("RIGHT")
			:SetWidth(100)
			:SetText("n\\a")
			.__END

	container.aucmodelgroup = ui:Create("RadioButtonGroup")
	container.aucmodelgroup:RegisterToggleCallback( function() Appraiser:SetSellAucMode() end )

	container.aucmodellabel = CHAIN(container.details:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("TOPLEFT",250,-120)
		:SetJustifyH("LEFT")
		:SetWidth(70)
		:SetText("Price per")
		.__END

	container.aucmodeunit = CHAIN(container.aucmodelgroup:AddRadio("unit",container))
		:SetPoint("LEFT",container.aucmodellabel ,"RIGHT",0,1)
		:SetFont(FONT,12)
		:SetText("Unit")
	.__END

	container.aucmodestack = CHAIN(container.aucmodelgroup:AddRadio("stack",container))
		:SetPoint("LEFT",container.aucmodeunit.text ,"RIGHT",15,0)
		:SetFont(FONT,12)
		:SetText("Stack")
	.__END


	container.aucmodelgroup:SetValue(ZGV.db.profile.aucmode or "unit")

	container.estvalreset = CHAIN(ui:Create("Button",container.details))
		:SetSize(185,20)
		:SetPoint("TOPLEFT",container.InventoryAuctionList ,"BOTTOMLEFT",0,-6)
		:SetFont(FONT,12)
		:SetText("Reset to Est. Value")
		:SetScript("OnClick", function() Appraiser:ResetSellData() end)
	.__END

	container.postbutton = CHAIN(ui:Create("Button",container,nil,2))
		:SetPoint("TOPRIGHT",container.InventoryAuctionList ,"BOTTOMRIGHT",0,-6)
		:SetSize(100,20)
		:SetText("Post")
		:SetFont(FONTBOLD,14)
		:SetScript("OnClick",function(me) Appraiser:StartAuction() end)
	.__END

	container.aucpostfee = CHAIN(container.details:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("TOPRIGHT",container.InventoryAuctionList ,"BOTTOMRIGHT",-20,-39)
		:SetJustifyH("RIGHT")
		:SetWidth(200)
		:SetText("Depost: "..ZGV.GetMoneyString(0))
		.__END

	return container
end

function Appraiser:MakeBuyTable()	
	local container = CHAIN(CreateFrame("Frame", "ZA_Buy_Frame", self.MainFrame.ContentFrame ))
		:SetPoint("TOPLEFT")
		:SetPoint("BOTTOMRIGHT")
		:SetHeight(100)
	.__END

	--------- Inventory list ---------
	container.ShoppingList = ui:Create("ScrollTable",container,"ZA_Shopping_Inventory",BUY_INVENTORY_COLUMS,BUY_INVENTORY_DATA)

	container.ShoppingList:SetScript("OnMouseWheel", function(self,delta)
		Appraiser.ShoppingOffset=Appraiser.ShoppingOffset-delta
		Appraiser.needToUpdate=true
		Appraiser.MainFrame.hideTooltip=true
	end)
	container.ShoppingList.scrollbar:SetScript("OnVerticalScroll",function(me,offset)
		Appraiser.ShoppingOffset=math.round(offset)
		Appraiser.needToUpdate=true
	end)

	for n=1,BUY_INVENTORY_DATA.ROW_COUNT do
		container.ShoppingList.rows[n].status:SetTexture(ZGV.DIR.."\\Skins\\goldpricestatusicons")
		container.ShoppingList.rows[n]:SetScript("OnClick",function(self,button)
			if container.ShoppingList.rows[n].item then
				if button == "LeftButton" then
					Appraiser:ActivateBuyItem(container.ShoppingList.rows[n].item)
				elseif button == "RightButton" then
					Appraiser:ShoppingRowMenu(container.ShoppingList.rows[n])
				end
			end
		end)
	end

	local containerDetails = CHAIN(CreateFrame("Frame", nil, container ))
		:SetPoint("TOPLEFT")
		:SetPoint("BOTTOMRIGHT")
		:SetHeight(100)
	.__END
	container.containerDetails=containerDetails

	--------- Auctions list ---------
	container.ShoppingAuctionList = ui:Create("ScrollTable",containerDetails,"ZA_Shopping_Auctions",BUY_AUCTIONS_COLUMNS,BUY_AUCTIONS_DATA)

	container.ShoppingAuctionList:SetScript("OnMouseWheel", function(self,delta)
		Appraiser.ShoppingAuctionOffset=Appraiser.ShoppingAuctionOffset-delta
		Appraiser.needToUpdate=true
		Appraiser.MainFrame.hideTooltip=true
	end)
	container.ShoppingAuctionList.scrollbar:SetScript("OnVerticalScroll",function(me,offset)
		Appraiser.ShoppingAuctionOffset=math.round(offset)
		Appraiser.needToUpdate=true
	end)
	for n=1,BUY_AUCTIONS_DATA.ROW_COUNT do
		container.ShoppingAuctionList.rows[n]:SetScript("OnClick",function()
			Appraiser:SetBuyoutToAuction(container.ShoppingAuctionList.rows[n])
		end)
	end

	container.auctionslabel = CHAIN(containerDetails:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("BOTTOMLEFT",container.ShoppingAuctionList,"TOPLEFT",0,0)
		:SetJustifyH("LEFT")
		:SetSize(435,20)
		:SetText("Auctions for: ...")
		.__END
	container.buyoutlabel = CHAIN(containerDetails:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("BOTTOMLEFT",container.ShoppingAuctionList,"TOPLEFT",0,0)
		:SetJustifyH("RIGHT")
		:SetSize(435,20)
		:SetText("Select auction to buy")
		.__END


	container.ShoppingAppraiseButton = CHAIN(ui:Create("Button",container))
		:SetSize(105,20)
		:SetPoint("TOPLEFT",container.ShoppingList,"BOTTOMLEFT", 0, -6)
		:SetFont(FONT,12)
		:SetText("Appraise all")
		:SetScript("OnClick", function() if not self.soft_disabled then Appraiser:UpdateBuyPrices() end end)
		:SetScript("OnEnter",function(self) 
			CHAIN(GameTooltip):SetOwner(self, "ANCHOR_BOTTOM") 
			:SetText(type(self.tooltip)=="function" and self:tooltip() or tostring(self.tooltip)) 
			:Show() 
			end)
		:SetScript("OnLeave",function(self) GameTooltip:Hide() end)
	.__END
	container.ShoppingAppraiseAbortButton = CHAIN(ui:Create("Button",container))
		:SetSize(105,20)
		:SetPoint("TOPLEFT",container.ShoppingList,"BOTTOMLEFT", 0, -6)
		:SetFont(FONT,12)
		:SetText("Abort")
		:SetScript("OnClick", function() Appraiser:AbortManualScan() end)
		:Hide()
	.__END

	container.ShoppingAddButton = CHAIN(ui:Create("Button",container))
		:SetSize(75,20)
		:SetPoint("TOPRIGHT",container.ShoppingList,"BOTTOMRIGHT", 0, -6)
		:SetFont(FONT,12)
		:SetText("Add item")
		:SetScript("OnClick", function() Appraiser:ToggleSearchFrame() end)
		:SetScript("OnEnter",function(self) 
			CHAIN(GameTooltip):SetOwner(self, "ANCHOR_BOTTOM") 
			:SetText("Add item to shopping list") 
			:Show() 
			end)
		:SetScript("OnLeave",function(self) GameTooltip:Hide() end)
	.__END

	container.activeIcon = CHAIN(containerDetails:CreateTexture())
		:SetPoint("TOPLEFT",container,"TOPLEFT",385,-8)
		:SetSize(20,20)
	.__END
	container.activeIconOverlay = CHAIN(ui:Create("Button",containerDetails,nil))
		:SetPoint("TOPLEFT",container.activeIcon)
		:SetPoint("BOTTOMRIGHT",container.activeIcon)
		:SetFrameLevel(container:GetFrameLevel()+2)
		:SetBackdropColor(0,0,0,0)
		:SetBackdropBorderColor(0,0,0,0)
		:SetScript("OnEnter",function()
			if Appraiser.ActiveShoppingItem and Appraiser.ActiveShoppingItem.itemid then
				GameTooltip:SetOwner(container.activeIconOverlay,"ANCHOR_RIGHT")
				GameTooltip:SetItemByID(Appraiser.ActiveShoppingItem.itemid )
				GameTooltip:Show()
			end
		end)
		:SetScript("OnLeave",function()
			GameTooltip:Hide()
		end)
	.__END	
	container.activeName = CHAIN(containerDetails:CreateFontString())
		:SetFont(FONT,13)
		:SetPoint("TOPLEFT",container.activeIcon,"TOPRIGHT",8,-2)
		:SetJustifyH("LEFT")
		:SetWidth(220)
		:SetWordWrap(false)
		:SetText("No item selected")
		.__END

	container.activeStatus = CHAIN(containerDetails:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("TOPLEFT",container.activeName,"TOPRIGHT",0,-2)
		:SetJustifyH("RIGHT")
		:SetWidth(190)
		:SetWordWrap(false)
		:SetText("No trend data for item.")
		.__END

	container.decor = CHAIN(ui:Create("Frame",containerDetails,nil))
		:SetPoint("TOPLEFT",container.activeIconOverlay,"BOTTOMLEFT",0,-2)
		:SetSize(438,1)
		:SetFrameLevel(container:GetFrameLevel()+3)
		:SetBackdropColor(0.3,0.3,0.3,1)
		:SetBackdropBorderColor(0,0,0,0)
	.__END

	container.details = CHAIN(CreateFrame("Frame", nil, containerDetails ))
		:SetPoint("TOPLEFT",container,"TOPLEFT",385,-30)
		:SetPoint("BOTTOMRIGHT",container.ShoppingAuctionList,"TOPRIGHT",0,-30)
	.__END

	container.nextbuyoutlabel = CHAIN(container.details:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("TOPLEFT",0,-10)
		:SetJustifyH("LEFT")
		:SetWidth(85)
		:SetText("Next buyout: ")
		.__END
		container.nextbuyout = CHAIN(container.details:CreateFontString())
			:SetFont(FONT,12)
			:SetPoint("LEFT",container.nextbuyoutlabel ,"RIGHT",5,0)
			:SetJustifyH("LEFT")
			:SetWidth(150)
			:SetText("n\\a")
			.__END
	container.amountbuyout = CHAIN(container.details:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("TOPLEFT",0,-32)
		:SetJustifyH("LEFT")
		:SetWidth(240)
		:SetText("")
		.__END

	container.extrainfolabel = CHAIN(container.details:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("TOPLEFT",0,-54)
		:SetJustifyH("LEFT")
		:SetWidth(270)
		:SetText("Defined max price: ")
		.__END

	container.histhighlabel = CHAIN(container.details:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("TOPLEFT",250,-10)
		:SetJustifyH("LEFT")
		:SetWidth(80)
		:SetText("Hist. High:")
		.__END
		container.histhigh = CHAIN(container.details:CreateFontString())
			:SetFont(FONT,12)
			:SetPoint("LEFT",container.histhighlabel ,"RIGHT",5,0)
			:SetJustifyH("RIGHT")
			:SetWidth(100)
			:SetText("n\\a")
			.__END
	container.histmedlabel = CHAIN(container.details:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("TOPLEFT",250,-32)
		:SetJustifyH("LEFT")
		:SetWidth(80)
		:SetText("Hist. Med:")
		.__END
		container.histmed = CHAIN(container.details:CreateFontString())
			:SetFont(FONT,12)
			:SetPoint("LEFT",container.histmedlabel ,"RIGHT",5,0)
			:SetJustifyH("RIGHT")
			:SetWidth(100)
			:SetText("n\\a")
			.__END
	container.histlowlabel = CHAIN(container.details:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("TOPLEFT",250,-54)
		:SetJustifyH("LEFT")
		:SetWidth(80)
		:SetText("Hist. Low:")
		.__END
		container.histlow = CHAIN(container.details:CreateFontString())
			:SetFont(FONT,12)
			:SetPoint("LEFT",container.histlowlabel ,"RIGHT",5,0)
			:SetJustifyH("RIGHT")
			:SetWidth(100)
			:SetText("n\\a")
			.__END
	container.estvallabel = CHAIN(container.details:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("TOPLEFT",250,-76)
		:SetJustifyH("LEFT")
		:SetWidth(80)
		:SetText("Est. Value:")
		.__END
		container.estval = CHAIN(container.details:CreateFontString())
			:SetFont(FONT,12)
			:SetPoint("LEFT",container.estvallabel ,"RIGHT",5,0)
			:SetJustifyH("RIGHT")
			:SetWidth(100)
			:SetText("n\\a")
			.__END

	container.estvalreset = CHAIN(ui:Create("Button",container.details))
		:SetSize(185,20)
		:SetPoint("TOPLEFT",container.ShoppingAuctionList ,"BOTTOMLEFT",0,-6)
		:SetFont(FONT,12)
		:SetText("Reset to suggested buyout")
		:SetScript("OnClick", function() Appraiser:ResetBuyoutToAuction() end)
	.__END

	container.postbutton = CHAIN(ui:Create("Button",containerDetails,nil,2))
		:SetPoint("TOPRIGHT",container.ShoppingAuctionList ,"BOTTOMRIGHT",0,-6)
		:SetSize(100,20)
		:SetText("Buy")
		:SetFont(FONTBOLD,14)
		:SetScript("OnClick",function(me) Appraiser:ExecuteBuyout() end)
		:SetScript("OnEnter",function(self) 
			CHAIN(GameTooltip):SetOwner(self, "ANCHOR_TOP") 
			:SetText(type(self.tooltip)=="function" and self:tooltip() or tostring(self.tooltip)) 
			:Show() 
			end)
		:SetScript("OnLeave",function(self) GameTooltip:Hide() end)
	.__END



	local containerSearch = CHAIN(CreateFrame("Frame", nil, container ))
		:SetPoint("TOPLEFT",container,"TOPLEFT",385,-10)
		:SetPoint("BOTTOMRIGHT",container.ShoppingAuctionList,"TOPRIGHT",0,0)
		:SetHeight(100)
	.__END
	container.containerSearch=containerSearch

	containerSearch.activeName = CHAIN(containerSearch:CreateFontString())
		:SetFont(FONT,13)
		:SetPoint("TOPLEFT",containerSearch,"TOPLEFT",0,-1)
		:SetJustifyH("LEFT")
		:SetWidth(220)
		:SetWordWrap(false)
		:SetText("Search/Add item")
		.__END
	containerSearch.activeStatus = CHAIN(containerSearch:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("TOPLEFT",containerSearch.activeName,"TOPRIGHT",0,-2)
		:SetJustifyH("RIGHT")
		:SetWidth(190)
		:SetWordWrap(false)
		:SetText("No results.")
		.__END
	containerSearch.decor = CHAIN(ui:Create("Frame",containerSearch,"ZASDASDADASD"))
		:SetPoint("TOPLEFT",containerSearch.activeName	,"BOTTOMLEFT",0,-6)
		:SetSize(438,1)
		:SetFrameLevel(containerSearch:GetFrameLevel()+3)
		:SetBackdropColor(0.3,0.3,0.3,1)
		:SetBackdropBorderColor(0,0,0,0)
	.__END


	containerSearch.description = CHAIN(containerSearch:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("TOPLEFT",0,-30)
		:SetJustifyH("LEFT")
		:SetWidth(400)
		:SetText("Select an item from the left panel or search for an item below:")
		.__END


	containerSearch.searchnamelabel = CHAIN(containerSearch:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("TOPLEFT",0,-52)
		:SetJustifyH("LEFT")
		:SetWidth(110)
		:SetText("Item name")
		.__END
		containerSearch.searchname = CHAIN(ui:Create("EditBox",containerSearch))
			:SetSize(314,17)
			:SetPoint("LEFT",containerSearch.searchnamelabel ,"RIGHT",5,0)
			:SetText("")
			:SetBackdropColor(0,0,0,1)
			:SetBackdropBorderColor(0.5,0.5,0.5,1)
			:SetTextColor(1,1,1,1)
			:SetScript("OnTabPressed", function() Appraiser:TabKeyNavigation(containerSearch,TAB_NAVIGATION_SEARCH,"searchname") end)
			:SetScript("OnEnterPressed",function(me) Appraiser:FindMatchingAuctions() end)
			.__END

	containerSearch.pricelabel = CHAIN(containerSearch:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("TOPLEFT",0,-74)
		:SetJustifyH("LEFT")
		:SetWidth(110)
		:SetText("Max price")
		.__END
		containerSearch.pricegold = CHAIN(ui:Create("EditBox",containerSearch))
			:SetSize(47,17)
			:SetPoint("LEFT",containerSearch.pricelabel ,"RIGHT",5,0)
			:SetText("0")
			:SetNumeric(true)
			:SetMaxLetters(6)
			:SetBackdropColor(0,0,0,1)
			:SetBackdropBorderColor(0.5,0.5,0.5,1)
			:SetTextColor(1,0.93,0,1)
			:SetScript("OnTabPressed", function() Appraiser:TabKeyNavigation(containerSearch,TAB_NAVIGATION_SEARCH,"pricegold") end)
			.__END
		containerSearch.pricesilver = CHAIN(ui:Create("EditBox",containerSearch))
			:SetSize(20,17)
			:SetPoint("LEFT",containerSearch.pricegold ,"RIGHT",12,0)
			:SetText("0")
			:SetNumeric(true)
			:SetMaxLetters(2)
			:SetBackdropColor(0,0,0,1)
			:SetBackdropBorderColor(0.5,0.5,0.5,1)
			:SetTextColor(0.97,0.97,1,1)
			:SetScript("OnTabPressed", function() Appraiser:TabKeyNavigation(containerSearch,TAB_NAVIGATION_SEARCH,"pricesilver") end)
			.__END
		containerSearch.pricecopper = CHAIN(ui:Create("EditBox",containerSearch))
			:SetSize(20,17)
			:SetPoint("LEFT",containerSearch.pricesilver ,"RIGHT",12,0)
			:SetText("0")
			:SetNumeric(true)
			:SetMaxLetters(2)
			:SetBackdropColor(0,0,0,1)
			:SetBackdropBorderColor(0.5,0.5,0.5,1)
			:SetTextColor(1,0.66,0.60,1)
			:SetScript("OnTabPressed", function() Appraiser:TabKeyNavigation(containerSearch,TAB_NAVIGATION_SEARCH,"pricecopper") end)
			.__END

	containerSearch.maxcountlabel = CHAIN(containerSearch:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("LEFT",containerSearch.pricecopper ,"RIGHT",70,0)
		:SetJustifyH("LEFT")
		:SetWidth(80)
		:SetText("Amount")
		.__END
		containerSearch.maxcount = CHAIN(ui:Create("EditBox",containerSearch))
			:SetSize(47,17)
			:SetPoint("LEFT",containerSearch.maxcountlabel ,"RIGHT",5,0)
			:SetText("")
			:SetNumeric(true)
			:SetBackdropColor(0,0,0,1)
			:SetBackdropBorderColor(0.5,0.5,0.5,1)
			:SetTextColor(1,1,1,1)
			:SetScript("OnTabPressed", function() Appraiser:TabKeyNavigation(containerSearch,TAB_NAVIGATION_SEARCH,"maxcount") end)
			.__END


	containerSearch.SearchResultList = ui:Create("ScrollTable",containerSearch,"ZA_Shopping_Search",BUY_SEARCH_COLUMNS,BUY_SEARCH_DATA)

	containerSearch.SearchResultList:SetScript("OnMouseWheel", function(self,delta)
		Appraiser.SearchResultsOffset=Appraiser.SearchResultsOffset-delta
		Appraiser.needToUpdate=true
		Appraiser.MainFrame.hideTooltip=true
	end)
	containerSearch.SearchResultList.scrollbar:SetScript("OnVerticalScroll",function(me,offset)
		Appraiser.SearchResultsOffset=math.round(offset)
		Appraiser.needToUpdate=true
	end)
	for n=1,BUY_SEARCH_DATA.ROW_COUNT do
		containerSearch.SearchResultList.rows[n].action:SetScript("OnClick",function()
			Appraiser:SaveSearchItem(containerSearch.SearchResultList.rows[n].item)
		end)
		containerSearch.SearchResultList.rows[n]:SetScript("OnClick",function()
			Appraiser:SaveSearchItem(containerSearch.SearchResultList.rows[n].item)
		end)
	end

	containerSearch.auctionslabel = CHAIN(containerSearch:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("BOTTOMLEFT",containerSearch.SearchResultList,"TOPLEFT",0,0)
		:SetJustifyH("LEFT")
		:SetSize(435,20)
		:SetText("Search results:")
		.__END
	containerSearch.undercutlabel = CHAIN(containerSearch:CreateFontString())
		:SetFont(FONT,12)
		:SetPoint("BOTTOMLEFT",containerSearch.SearchResultList,"TOPLEFT",0,0)
		:SetJustifyH("RIGHT")
		:SetSize(435,20)
		:SetText("Click to select:")
		.__END


	containerSearch.clearresults = CHAIN(ui:Create("Button",containerSearch))
		:SetSize(185,20)
		:SetPoint("TOPLEFT",containerSearch.SearchResultList ,"BOTTOMLEFT",0,-6)
		:SetFont(FONT,12)
		:SetText("Clear search results")
		:SetScript("OnClick", function() Appraiser:ClearSearchData() end)
	.__END

	containerSearch.searchbutton = CHAIN(ui:Create("Button",containerSearch,nil,2))
		:SetPoint("TOPRIGHT",containerSearch.SearchResultList ,"BOTTOMRIGHT",0,-6)
		:SetSize(100,20)
		:SetText("Search")
		:SetFont(FONTBOLD,14)
		:SetScript("OnClick",function(me) Appraiser:FindMatchingAuctions() end)
		--[[
		:SetScript("OnEnter",function(self) 
			CHAIN(GameTooltip):SetOwner(self, "ANCHOR_BOTTOM") 
			:SetText(type(self.tooltip)=="function" and self:tooltip() or tostring(self.tooltip)) 
			:Show() 
			end)
		--]]
		:SetScript("OnLeave",function(self) GameTooltip:Hide() end)
	.__END

	container.playergold = CHAIN(container:CreateFontString())
		:SetFont(FONT,12)
		:SetJustifyH("RIGHT")
		:SetWidth(200)
		:SetText("Player gold: "..ZGV.GetMoneyString(GetMoney()))
		:SetPoint("BOTTOMRIGHT",container,"BOTTOMRIGHT",-30,-20)
		.__END

	container.containerDetails:Hide()
	container.containerSearch:Show()

	return container
end

function Appraiser:ActivateTab(tabname)
	for i=1, AuctionFrame.numTabs do
		if _G["AuctionFrameTab"..i].ZygorTarget and _G["AuctionFrameTab"..i].ZygorTarget==tabname then
			_G["AuctionFrameTab"..i]:Click()
			break
		end
	end
end

function Appraiser:SetCurrentTab(tabname)
	local windows = {Buy="Buy",Inventory="Sell"}
	for framename,framedispname in pairs(windows) do
		self[framename.."_Frame"]:Hide()
	end
	self[tabname.."_Frame"]:Show()

	self.MainFrame.HeaderFrame.Title:SetText(windows[tabname])

	self.ActiveTab = tabname

	if ZGV.db.profile.autoscan and not Appraiser.Autoscanned then -- run autoscan only when our tab is active
		Appraiser.Autoscanned=true
		Appraiser:Scan()
	end

	Appraiser:Update()
end

function Appraiser:ShowWindow()
	if not ZGV.db.profile.auction_enable then return end

	if not self.MainFrame then self:CreateMainFrame() end

	ZGV.db.profile.IsWidgetCollapsed = ZGV.db.profile.IsWidgetCollapsed or {}
	if not ZGV.db.profile.IsWidgetCollapsed["Appraiser"] then
		ZGV.db.profile.IsWidgetCollapsed["Appraiser"] = false
	end
	
	Appraiser.InventoryOffset=0
	Appraiser.InventoryAuctionOffset=0
	Appraiser.ShoppingOffset=0
	Appraiser.SearchResultsOffset=0
	Appraiser.ShoppingAuctionOffset=0
	if ZGV.db.profile.auction_autoshow_tab then
		self:ActivateTab("Inventory")
	end
end

function Appraiser:HideWindow()
	if self.MainFrame then
		self.MainFrame:Hide()
	end
end

local function OldColor(timestamp,red,yellow)
	local age=time()-timestamp
	if age>red then
		return "ffff0000"
	elseif age>yellow then
		return "ffffee00"
	else
		return "ffffffff"
	end
end

function Appraiser:UpdateTimeStamp()
	if not self.MainFrame then return end
	if not self.lastScanTime then self.lastScanTime = time() end

	local timestamptext,updateTitletext,lastScanStr


	if ZGVG.Scan.db.realm.LastScan then
		updateTitletext = "LAST UPDATED:"
		timestamptext = ("|c%s%s|r"):format(OldColor(ZGV.db.realm.LastScan,3600*2,60*10), ui.GetTimeStamp(ZGV.db.realm.LastScan))
		if time()-ZGV.db.realm.LastScan > 3600*2 then
			timestamptext = timestamptext .. "|r - " .. L["gold_app_old_scan_data"]
		end
	else
		updateTitletext = "|cffff0000ALERT:|r"
		timestamptext = L["gold_app_no_scan_data"]
	end

	if not ZGV.Gold.guides_loaded then
		updateTitletext = "|cffff0000ALERT:|r"
		timestamptext = L["gold_app_no_goldguide"]
	elseif not (ZGV.Gold.servertrends and ZGV.Gold.servertrends.date) then
		updateTitletext = "|cffff0000ALERT:|r"
		timestamptext = L["gold_app_no_servertrends"]
	elseif ZGV.Gold.servertrends.date then
		local timeSinceLast = time() -  ZGV.Gold.servertrends.date

		if timeSinceLast > TRENDS_OLD * 3600 then	-- Data is old
			updateTitletext = "|cffff0000ALERT:|r"
			timestamptext = L["gold_app_old_servertrends"]:format(ui.GetTimeStamp(tonumber(ZGV.Gold.servertrends.date)))
		end
	end

	local local_time = debugprofilestop()
	local progress_dots = ""

	if (math.floor(local_time%1500) < 500) then
		progress_dots = "."
	elseif local_time%1500 < 1000 then
		progress_dots = ".."
	else
		progress_dots = "..."
	end

	local data_text = "auctions"

	if Appraiser.oldstate ~= ZGV.Gold.Scan.state then
		Appraiser.oldstate = ZGV.Gold.Scan.state
		if Appraiser.oldstate == "SS_QUERYING" then
			Appraiser.pagenum = (Appraiser.pagenum or 0) + 1
		end
	end

	local page_text = ""
	if Appraiser.pagenum then
		page_text = "page "..Appraiser.pagenum.." of "
	end

	if Appraiser.manualScanning then
		data_text = page_text..(Appraiser.manualScanningName or "")
	end
	if Appraiser.UpdateScanRunningName then
		data_text = page_text..self.UpdateScanRunningName
	end
	if Appraiser.BuyOutSearchName then
		data_text = page_text..Appraiser.BuyOutSearchName
	end



	if ZGV.Gold.Scan.state == "SS_QUERYING" then
		updateTitletext = "|cffff0000SCANNING:|r"
		timestamptext = "Querying "..data_text.." data (stage 1/4)" .. progress_dots
	elseif ZGV.Gold.Scan.state =="SS_RECEIVING" then
		updateTitletext = "|cffff0000SCANNING:|r"
		timestamptext = "Receiving "..data_text.." data (stage 2/4)"  .. progress_dots
	elseif ZGV.Gold.Scan.state =="SS_SCANNING" then
		updateTitletext = "|cffff0000SCANNING:|r"
		timestamptext = "Scanning "..data_text.." data (stage 3/4, " .. ("%d"):format((ZGV.Gold.Scan.scan_progress or 0)*100) .. "%)" .. progress_dots
	elseif ZGV.Gold.Scan.state =="SS_ANALYZING" then
		updateTitletext = "|cffff0000SCANNING:|r"
		timestamptext = "Analyzing "..data_text.." data (stage 4/4)" .. progress_dots
	elseif Appraiser.ScanIsRunning or Appraiser.ActiveShoppingAddItem or Appraiser.ScanItems and next(Appraiser.ScanItems) then
		-- show Analyzing to avoid idle flashes
		updateTitletext = "|cffff0000SCANNING:|r"
		timestamptext = "Analyzing "..data_text.." data" .. progress_dots
	elseif ZGV.Gold.Scan.state =="SS_IDLE" then
		Appraiser.pagenum = nil
	end



	self.MainFrame.FooterUpdated:SetText(updateTitletext)
	self.MainFrame.FooterUpdatedTime:SetText(timestamptext)
end

function Appraiser:ShowDisabledTooltip(object)
	GameTooltip:SetOwner(object,"ANCHOR_RIGHT") 
	GameTooltip:SetText("Due to a bug in Blizzard's in Auction House functionality,\npets and equipment can only be posted one by one.") 
	GameTooltip:Show()
end



--------------------------- Blizzard UI tabs
function Appraiser:OnZygorTabClick(tab)
	AuctionFrameTopLeft:Hide()
	AuctionFrameTop:Hide()
	AuctionFrameTopRight:Hide()
	AuctionFrameBotLeft:Hide()
	AuctionFrameBot:Hide()
	AuctionFrameBotRight:Hide()
	AuctionFrameMoneyFrame:Hide()
	AuctionFrameCloseButton:Hide()
	AuctionPortraitTexture:Hide()

	self.MainFrame:Show()
	Appraiser:SetCurrentTab(tab.ZygorTarget)
end

function Appraiser:OnNonZygorClick()
	AuctionFrameTopLeft:Show()
	AuctionFrameTop:Show()
	AuctionFrameTopRight:Show()
	AuctionFrameBotLeft:Show()
	AuctionFrameBot:Show()
	AuctionFrameBotRight:Show()
	AuctionFrameMoneyFrame:Show()
	AuctionFrameCloseButton:Show()
	AuctionPortraitTexture:Show()
	self.MainFrame:Hide()
end

function Appraiser:CreateSystemTab(target,text,num)
	local function TabChangeHook(self)
		Appraiser:HideHelpPage()
		if self.ZygorTab then
			Appraiser:OnZygorTabClick(self)
		else
			Appraiser:OnNonZygorClick()
		end
	
	end

	if not Appraiser.TabChange_Hooked then
		Appraiser:Hook("AuctionFrameTab_OnClick", TabChangeHook, true)
		Appraiser.TabChange_Hooked = true
	end

	local auctionTab = CreateFrame("Frame", nil, AuctionFrame)
	auctionTab:Hide()
	auctionTab:SetAllPoints()
	auctionTab:EnableMouse(true)
	auctionTab:SetMovable(true)
	auctionTab:SetScript("OnMouseDown", function() if AuctionFrame:IsMovable() then AuctionFrame:StartMoving() end end)
	auctionTab:SetScript("OnMouseUp", function() if AuctionFrame:IsMovable() then AuctionFrame:StopMovingOrSizing() end end)
	auctionTab.module = "Zygor Seller"

	local n = AuctionFrame.numTabs + 1

	local tab = CreateFrame("Button", "AuctionFrameTab"..n, AuctionFrame, "AuctionTabTemplate")
	tab:Hide()
	tab:SetID(n)
	tab:SetText("|cfffe6000"..text)
	tab:SetNormalFontObject(GameFontHighlightSmall)
	tab:SetPoint("LEFT", _G["AuctionFrameTab"..n-1], "RIGHT", -8, 0)
	tab:Show()
	tab.ZygorTab = true
	tab.ZygorTarget = target
	PanelTemplates_SetNumTabs(AuctionFrame, n)
	PanelTemplates_EnableTab(AuctionFrame, n)
end


function Appraiser:TabKeyNavigation(parent,orderarray,field)
	-- Get current index
	local orderindex,nextindex,previndex
	for oi,orderfield in pairs(orderarray) do if orderfield==field then orderindex=oi break end end

	nextindex,previndex = orderindex+1, orderindex-1
	if orderindex == #orderarray then nextindex=1 end
	if orderindex == 1 then previndex=#orderarray end

	parent[orderarray[orderindex]]:HighlightText(0,0)

	if ( IsShiftKeyDown() ) then
		parent[orderarray[previndex]]:SetFocus()
		parent[orderarray[previndex]]:HighlightText()
	else
		parent[orderarray[nextindex]]:SetFocus()
		parent[orderarray[nextindex]]:HighlightText()
	end
end

function Appraiser:ShowHelpPage()	
	Appraiser.MainFrame.HelpPage:Show()
	if Appraiser.Buy_Frame:IsVisible() then
		Appraiser.MainFrame.HelpPageContent:SetText(Appraiser.BuyTabInfo)
	else
		Appraiser.MainFrame.HelpPageContent:SetText(Appraiser.SellTabInfo)
	end
end

function Appraiser:HideHelpPage()
	Appraiser.MainFrame.HelpPage:Hide()
end

function Appraiser:ToggleHelpPage()
	if not Appraiser.MainFrame.HelpPage:IsVisible() then
		Appraiser:ShowHelpPage()
	else
		Appraiser:HideHelpPage()
	end
end