if GetLocale()~="zhCN" then return end

ZygorGuidesViewer_L("Main", "zhCN", function() return {
	--LocaleFont = [[Fonts\ZYKai_T.ttf]],
	MainFont = [[Fonts\bHEI01B.TTF]],
	MainFontBold = [[Fonts\bHEI01B.TTF]],
} end)
